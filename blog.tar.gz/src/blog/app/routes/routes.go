// GENERATED CODE - DO NOT EDIT
package routes

import "github.com/revel/revel"


type tMain struct {}
var Main tMain


func (_ tMain) Main(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Main.Main", args).Url
}

func (_ tMain) Blog4Category(
		ca string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "ca", ca)
	return revel.MainRouter.Reverse("Main.Blog4Category", args).Url
}


type tUpload struct {}
var Upload tUpload


func (_ tUpload) Before(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Upload.Before", args).Url
}

func (_ tUpload) HandleUpload(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Upload.HandleUpload", args).Url
}


type tBlog struct {}
var Blog tBlog


func (_ tBlog) BlogPage(
		ident string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "ident", ident)
	return revel.MainRouter.Reverse("Blog.BlogPage", args).Url
}


type tComment struct {}
var Comment tComment


func (_ tComment) NewComment(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Comment.NewComment", args).Url
}

func (_ tComment) DelComment(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Comment.DelComment", args).Url
}

func (_ tComment) ModifyComment(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Comment.ModifyComment", args).Url
}


type tLogin struct {}
var Login tLogin


func (_ tLogin) SignIn(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Login.SignIn", args).Url
}

func (_ tLogin) SignInHandler(
		name string,
		passwd string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "name", name)
	revel.Unbind(args, "passwd", passwd)
	return revel.MainRouter.Reverse("Login.SignInHandler", args).Url
}

func (_ tLogin) SignUp(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Login.SignUp", args).Url
}

func (_ tLogin) SignOut(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Login.SignOut", args).Url
}

func (_ tLogin) SignUpHandler(
		name string,
		email string,
		passwd string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "name", name)
	revel.Unbind(args, "email", email)
	revel.Unbind(args, "passwd", passwd)
	return revel.MainRouter.Reverse("Login.SignUpHandler", args).Url
}


type tSearch struct {}
var Search tSearch


func (_ tSearch) Index(
		q string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "q", q)
	return revel.MainRouter.Reverse("Search.Index", args).Url
}


type tAdmin struct {}
var Admin tAdmin


func (_ tAdmin) AdminChecker(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Admin.AdminChecker", args).Url
}

func (_ tAdmin) Main(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Admin.Main", args).Url
}


type tBlogTag struct {}
var BlogTag tBlogTag


func (_ tBlogTag) Index(
		ident string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "ident", ident)
	return revel.MainRouter.Reverse("BlogTag.Index", args).Url
}

func (_ tBlogTag) GetAllTags(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("BlogTag.GetAllTags", args).Url
}

func (_ tBlogTag) QueryTags(
		t string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "t", t)
	return revel.MainRouter.Reverse("BlogTag.QueryTags", args).Url
}


type tInstall struct {}
var Install tInstall


func (_ tInstall) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Install.Index", args).Url
}

func (_ tInstall) HandleInstall(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Install.HandleInstall", args).Url
}

func (_ tInstall) AddAdmin(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Install.AddAdmin", args).Url
}

func (_ tInstall) AddDB(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Install.AddDB", args).Url
}


type tStatic struct {}
var Static tStatic


func (_ tStatic) Serve(
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.Serve", args).Url
}

func (_ tStatic) ServeModule(
		moduleName string,
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "moduleName", moduleName)
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.ServeModule", args).Url
}


type tTestRunner struct {}
var TestRunner tTestRunner


func (_ tTestRunner) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("TestRunner.Index", args).Url
}

func (_ tTestRunner) Suite(
		suite string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "suite", suite)
	return revel.MainRouter.Reverse("TestRunner.Suite", args).Url
}

func (_ tTestRunner) Run(
		suite string,
		test string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "suite", suite)
	revel.Unbind(args, "test", test)
	return revel.MainRouter.Reverse("TestRunner.Run", args).Url
}

func (_ tTestRunner) List(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("TestRunner.List", args).Url
}


type tCategory struct {}
var Category tCategory


func (_ tCategory) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Category.Index", args).Url
}

func (_ tCategory) ListAll(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Category.ListAll", args).Url
}

func (_ tCategory) EditPage(
		cid int64,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "cid", cid)
	return revel.MainRouter.Reverse("Category.EditPage", args).Url
}

func (_ tCategory) AddPage(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Category.AddPage", args).Url
}

func (_ tCategory) Add(
		ca_name string,
		ca_ident string,
		ca_p int,
		ca_id int,
		ca_desc string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "ca_name", ca_name)
	revel.Unbind(args, "ca_ident", ca_ident)
	revel.Unbind(args, "ca_p", ca_p)
	revel.Unbind(args, "ca_id", ca_id)
	revel.Unbind(args, "ca_desc", ca_desc)
	return revel.MainRouter.Reverse("Category.Add", args).Url
}

func (_ tCategory) Del(
		id int,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "id", id)
	return revel.MainRouter.Reverse("Category.Del", args).Url
}


type tSetting struct {}
var Setting tSetting


func (_ tSetting) SiteSetPage(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Setting.SiteSetPage", args).Url
}

func (_ tSetting) SiteSetHandler(
		title string,
		subtitle string,
		url string,
		seo string,
		reg string,
		foot string,
		statistics string,
		status string,
		comment string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "title", title)
	revel.Unbind(args, "subtitle", subtitle)
	revel.Unbind(args, "url", url)
	revel.Unbind(args, "seo", seo)
	revel.Unbind(args, "reg", reg)
	revel.Unbind(args, "foot", foot)
	revel.Unbind(args, "statistics", statistics)
	revel.Unbind(args, "status", status)
	revel.Unbind(args, "comment", comment)
	return revel.MainRouter.Reverse("Setting.SiteSetHandler", args).Url
}


type tUser struct {}
var User tUser


func (_ tUser) Main(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("User.Main", args).Url
}

func (_ tUser) Edit(
		id int64,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "id", id)
	return revel.MainRouter.Reverse("User.Edit", args).Url
}

func (_ tUser) EditHandler(
		username string,
		nickname string,
		password string,
		email string,
		group int,
		id int64,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "username", username)
	revel.Unbind(args, "nickname", nickname)
	revel.Unbind(args, "password", password)
	revel.Unbind(args, "email", email)
	revel.Unbind(args, "group", group)
	revel.Unbind(args, "id", id)
	return revel.MainRouter.Reverse("User.EditHandler", args).Url
}

func (_ tUser) Create(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("User.Create", args).Url
}

func (_ tUser) CreateHandler(
		username string,
		nickname string,
		password string,
		email string,
		group int,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "username", username)
	revel.Unbind(args, "nickname", nickname)
	revel.Unbind(args, "password", password)
	revel.Unbind(args, "email", email)
	revel.Unbind(args, "group", group)
	return revel.MainRouter.Reverse("User.CreateHandler", args).Url
}

func (_ tUser) Delete(
		ids string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "ids", ids)
	return revel.MainRouter.Reverse("User.Delete", args).Url
}


type tPost struct {}
var Post tPost


func (_ tPost) Index(
		postid int64,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "postid", postid)
	return revel.MainRouter.Reverse("Post.Index", args).Url
}

func (_ tPost) ManagePost(
		uid int64,
		category int64,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "uid", uid)
	revel.Unbind(args, "category", category)
	return revel.MainRouter.Reverse("Post.ManagePost", args).Url
}

func (_ tPost) NewPostHandler(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Post.NewPostHandler", args).Url
}

func (_ tPost) QueryCategorys(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Post.QueryCategorys", args).Url
}

func (_ tPost) CreateTag(
		name string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "name", name)
	return revel.MainRouter.Reverse("Post.CreateTag", args).Url
}

func (_ tPost) Delete(
		ids string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "ids", ids)
	return revel.MainRouter.Reverse("Post.Delete", args).Url
}


type tAdminTag struct {}
var AdminTag tAdminTag


func (_ tAdminTag) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("AdminTag.Index", args).Url
}

func (_ tAdminTag) Edit(
		tagID int64,
		tagName string,
		tagIdent string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "tagID", tagID)
	revel.Unbind(args, "tagName", tagName)
	revel.Unbind(args, "tagIdent", tagIdent)
	return revel.MainRouter.Reverse("AdminTag.Edit", args).Url
}

func (_ tAdminTag) Del(
		ids string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "ids", ids)
	return revel.MainRouter.Reverse("AdminTag.Del", args).Url
}


