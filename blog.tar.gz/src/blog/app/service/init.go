package service

func Init() {
	InitSearcher()
}
