curl --connect-timeout 20 --max-time 30 -s http://laily.me:8008/ci/blog 
