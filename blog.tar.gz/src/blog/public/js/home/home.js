var Home ={
    toSearch: function(){
        location.href="/search?q="+$("#search-key").val();
    }
}